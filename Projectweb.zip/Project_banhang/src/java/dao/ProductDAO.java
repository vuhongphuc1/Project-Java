/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import entity.Category;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import entity.Product;

/**
 *
 * @author Admin
 */
public class ProductDAO extends DBContext {

    public ArrayList<Product> getAllProduct() {
        ArrayList<Product> productses = new ArrayList<>();
        try {
            String sql = "SELECT [ProductID]\n"
                    + "      ,[ProductName]\n"
                    + "      ,[UnitPrice]\n"
                    + "      ,[Image]\n"
                    + "  FROM [dbo].[Product]";
            PreparedStatement stm = connection.prepareStatement(sql);
            ResultSet rs = stm.executeQuery();
            while (rs.next()) {
                Product p = new Product();
                p.setProductId(rs.getString("productId"));
                p.setProductName(rs.getString("productName"));
                p.setPrice(rs.getDouble("unitprice"));
                p.setImg(rs.getString("image"));
                productses.add(p);
            }

        } catch (SQLException ex) {
            Logger.getLogger(ProductDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return productses;
    }

    public ArrayList<Product> getProductByCid(String cid) {
        ArrayList<Product> productses = new ArrayList<>();
        try {
            String sql = "SELECT [ProductID]\n"
                    + "      ,[ProductName]\n"
                    + "      ,[CategoryID]\n"
                    + "      ,[UnitPrice]\n"
                    + "      ,[Image]\n"
                    + "  FROM [dbo].[Product]\n"
                    + "  where CategoryID = ?";
            PreparedStatement stm = connection.prepareStatement(sql);
            stm.setString(1, cid);
            ResultSet rs = stm.executeQuery();
            while (rs.next()) {
                Product p = new Product();
                p.setProductId(rs.getString("productId"));
                p.setProductName(rs.getString("productName"));
                p.setPrice(rs.getDouble("unitprice"));
                p.setImg(rs.getString("image"));
                productses.add(p);
            }

        } catch (SQLException ex) {
            Logger.getLogger(ProductDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return productses;
    }

    public ArrayList<Product> searchByName(String txtSearch) {
        ArrayList<Product> productses = new ArrayList<>();
        try {
            String sql = "SELECT [ProductID]\n"
                    + "      ,[ProductName]\n"
                    + "      ,[CategoryID]\n"
                    + "      ,[UnitPrice]\n"
                    + "      ,[Image]\n"
                    + "  FROM [dbo].[Product]\n"
                    + "  where ProductName like ?";
            PreparedStatement stm = connection.prepareStatement(sql);
            stm.setString(1, "%" + txtSearch + "%");
            ResultSet rs = stm.executeQuery();
            while (rs.next()) {
                Product p = new Product();
                p.setProductId(rs.getString("productId"));
                p.setProductName(rs.getString("productName"));
                p.setPrice(rs.getDouble("unitprice"));
                p.setImg(rs.getString("image"));
                productses.add(p);
            }

        } catch (SQLException ex) {
            Logger.getLogger(ProductDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return productses;
    }

    public Product getProductByID(String id) {

        try {
            String sql = "SELECT [ProductID]\n"
                    + "      ,[ProductName]\n"
                    + "      ,[CategoryID]\n"
                    + "      ,[UnitPrice]\n"
                    + "      ,[Image]\n"
                    + "  FROM [dbo].[Product]\n"
                    + "  where ProductID = ?";
            PreparedStatement stm = connection.prepareStatement(sql);
            stm.setString(1, id);
            ResultSet rs = stm.executeQuery();
            while (rs.next()) {
                Product p = new Product();
                p.setProductId(rs.getString("productId"));
                p.setProductName(rs.getString("productName"));
                p.setPrice(rs.getDouble("unitprice"));
                p.setImg(rs.getString("image"));
                return p;
            }

        } catch (SQLException ex) {
            Logger.getLogger(ProductDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    public ArrayList<Category> getAllCategory() {
        ArrayList<Category> categorys = new ArrayList<>();
        try {
            String sql = "SELECT [CategoryID]\n"
                    + "      ,[CategoryName]\n"
                    + "  FROM [dbo].[Categorios]";
            PreparedStatement stm = connection.prepareStatement(sql);
            ResultSet rs = stm.executeQuery();
            while (rs.next()) {
                Category c = new Category();
                c.setCid(rs.getString("CategoryID"));
                c.setCname(rs.getString("CategoryName"));
                categorys.add(c);
            }

        } catch (SQLException ex) {
            Logger.getLogger(ProductDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return categorys;
    }

    public void deleteProduct(String pid) {
        try {
            String sql = "Delete from Product "
                    + "where productID = ?";
            PreparedStatement stm = connection.prepareStatement(sql);
            stm.setString(1, pid);
            stm.executeUpdate();
        } catch (Exception e) {
        }
    }

    public void insertProduct(String id, String name, String image, String price,String category,  int sid) {
        String sql = "INSERT INTO [Product]\n"
                + "           ([ProductID]\n"
                + "           ,[ProductName]\n"
                + "           ,[CategoryID]\n"
                + "           ,[UnitPrice]\n"
                + "           ,[Image]\n"
                + "           ,[sellid])"
                + "VALUES\n"
                + "(?"
                + ",?"
                + ",?"
                + ",?"
                + ",?"
                + ",?)";
        try {
            PreparedStatement stm = connection.prepareStatement(sql);
            stm.setString(1, id);
            stm.setString(2, name);
            stm.setString(3, image);
            stm.setString(4, price);
            stm.setString(5, category);
            stm.setInt(6, sid);
            stm.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(ProductDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void editProduct(String name, String image, String price,
            String category, String pid) {
        String sql = "update Product\n"
                + "set [ProductName] = ?,\n"
                + "[image] = ?,\n"
                + "UnitPrice = ?,\n"
                + "CategoryID = ?\n"
                + "where ProductID = ?";
        try {
            PreparedStatement stm = connection.prepareStatement(sql);

            stm.setString(1, name);
            stm.setString(2, image);
            stm.setString(3, price);
            stm.setString(4, category);
            stm.setString(5, pid);
            stm.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(ProductDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public int getTotalProduct() {
        try {
            String sql = "select count(*) from Product";
            PreparedStatement stm = connection.prepareStatement(sql);
            ResultSet rs = stm.executeQuery();
            while (rs.next()) {
                return rs.getInt(1);
            }

        } catch (SQLException ex) {
            Logger.getLogger(ProductDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return 0;
    }

    public ArrayList<Product> pagingProduct(int index) {
        ArrayList<Product> list = new ArrayList<>();
        try {
            String sql = "Select * from Product \n"
                    + "order by ProductID "
                    + "OFFSET ? rows fetch next 6 rows only";
            PreparedStatement stm = connection.prepareStatement(sql);
            stm.setInt(1, (index - 1) * 6);
            ResultSet rs = stm.executeQuery();
            while (rs.next()) {
                Product p = new Product();
                p.setProductId(rs.getString("productId"));
                p.setProductName(rs.getString("productName"));
                p.setCategoryId(rs.getString("categoryId"));
                p.setPrice(rs.getDouble("unitPrice"));
                p.setImg(rs.getString("image"));
                list.add(p);
            }

        } catch (SQLException ex) {
        }
        return list;

    }

    public static void main(String[] args) {
        ProductDAO dAO = new ProductDAO();
        dAO.insertProduct("acccc","b","2", "2", "avc", 2);
        ArrayList<Product> p = dAO.getAllProduct();
        System.out.println(p);
        for (Product o : p ) {
           System.out.println(o);
        }
    }
}
